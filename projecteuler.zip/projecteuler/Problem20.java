package projecteuler;

import java.math.BigInteger;
import java.util.HashMap;

/**
 * This class demonstrates one of the solutions for 
 * Project Euler Problem 20:
 * Factorial digit sum - n! means n × (n − 1) × ... × 3 × 2 × 1
 * For example, 10! = 10 × 9 × ... × 3 × 2 × 1 = 3628800,
 * and the sum of the digits in the number 10! 
 * is 3 + 6 + 2 + 8 + 8 + 0 + 0 = 27.
 * Find the sum of the digits in the number 100!
 * 
 * @author cc dorland
 * 
 */
public class Problem20 {
    
	private HashMap<Integer, BigInteger> numToFactorialMap = new HashMap<Integer,BigInteger>();
	
	//this method provides the answer submitted to Euler
	public void getAnswerForEuler(){
		getAnswer(100);
	}
	//this method answers the question and execution time
	public void getAnswer(int num){
		long startTime = System.currentTimeMillis();
		long answer = getFactorialDigitSum(num);
		long endTime = System.currentTimeMillis();
		long time = endTime - startTime;
		System.out.println("Answer for Problem 20: "+answer+"           Execution time in milliseconds: "+time);
	}
	
	//this method gets the factorial for the specified num
	//it also caches the factorial values for future use
	public BigInteger getFactorial(int num){
		if (num < 0) {
			return BigInteger.valueOf(-1);
		}
		
		if (numToFactorialMap.get(num) != null){
			return numToFactorialMap.get(num);
		}
		//0! factorial is 1
		//1! factorial is 1
		if ((num == 0) || (num == 1)){
			numToFactorialMap.put(num,BigInteger.valueOf(1) );
			return BigInteger.valueOf(1);
		}
		BigInteger sum=BigInteger.valueOf(1);
		for (int i=2;i<=num;i++){
			sum = sum.multiply(BigInteger.valueOf(i));
		}
		numToFactorialMap.put(num, sum);
		return sum;
	}
	
	//this method adds the digits of the factorial
	private long getDigitsSum(BigInteger num){
		//return -1 if the num is negative,
		//could throw an exception...
		if ((num == null) || (num.signum() == -1)){
			return -1;
		}
	
		long sum = 0;
		//the loop stops when it reaches the left most digit
		while (num.signum() > 0){
			long digit = num.mod(BigInteger.valueOf(10)).longValue();
			sum +=digit;
			num = num.divide(BigInteger.valueOf(10));;
		}
		return sum;
	}
	
	//to get the factorial for the input number and adds the digits
	public long getFactorialDigitSum(int num){
		if (num < 0){
		   System.err.println("invalid input number for Problem 20: "+num);
		   return -1;
		}
		BigInteger sumNum = getFactorial(num);
		if (sumNum.signum() == -1){
			return -1;
		}
		long sumDigits = getDigitsSum(sumNum);
		return sumDigits;
	}
	
	//for testing purpose
	private long testGetFactorialDigitSum (int num){
		long res = getFactorialDigitSum(num);
		if (res != -1)
			System.out.println("input number for Problem 20: "+num);
		return res;
	}
	
	//test cases
	public static void main(String[] args) {
		Problem20 problem = new Problem20();
		System.out.println(problem.testGetFactorialDigitSum(-1));
		System.out.println(problem.testGetFactorialDigitSum(0));
		System.out.println(problem.testGetFactorialDigitSum(1));
		System.out.println(problem.testGetFactorialDigitSum(20));
		System.out.println(problem.testGetFactorialDigitSum(10));
		System.out.println(problem.testGetFactorialDigitSum(100));
	}


}
