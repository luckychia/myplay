package projecteuler;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * This class demonstrates one of the solutions for 
 * Project Euler Problem 10:
 * Summation of primes - The sum of the primes below 10 
 * is 2 + 3 + 5 + 7 = 17. 
 * Find the sum of all the primes below two million.
 * 
 * @author cc dorland
 * 
 */
public class Problem10 {
     
	//this method provides the answer submitted to Euler
	public void getAnswerForEuler(){
		getAnswer(2000000);
	}
	//this method answers the question and execution time
	public void getAnswer(int seq){
		long startTime = System.currentTimeMillis();
		BigInteger answer = getSummationOfPrimes(seq);
		long endTime = System.currentTimeMillis();
		long time = endTime - startTime;
		System.out.println("Answer for Problem 10: "+answer+"  Execution time in milliseconds: "+time);
	}
	
	//this method adds all found prime numbers 
	//use BigIntefer for summation
	public BigInteger getSummationOfPrimes(long num){
		if (num < 2) {
			System.err.println("invalid input number for Problem 10: "+num);
			return BigInteger.valueOf(-1);
		}
		//find the prime numbers that are less than input num
		BigInteger sum = BigInteger.ZERO;
		for (long i=2;i<num;i++){
			if (Utils.isPrime(i)){
				sum = sum.add(BigInteger.valueOf(i));
			}
		}
		return sum;
	}
	
	//for testing use
	private BigInteger testGetSumOfAllPrimes(int num){
		BigInteger res=getSummationOfPrimes(num);
		if (res.signum() != -1)
			System.out.println("input number for Problem 10: "+num);
		return res;
	}
	
	//test cases
	public static void main(String[] args) {
		Problem10 problem = new Problem10();
		System.out.println(problem.testGetSumOfAllPrimes(-1));
		System.out.println(problem.testGetSumOfAllPrimes(0));
		System.out.println(problem.testGetSumOfAllPrimes(1));
		System.out.println(problem.testGetSumOfAllPrimes(2));
		System.out.println(problem.testGetSumOfAllPrimes(3));
		System.out.println(problem.testGetSumOfAllPrimes(10000));
		System.out.println(problem.testGetSumOfAllPrimes(10));
		System.out.println(problem.testGetSumOfAllPrimes(2000000));
	}



}
