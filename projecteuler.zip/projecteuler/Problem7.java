package projecteuler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

/**
 * This class demonstrates one of the solutions for 
 * Project Euler Problem 7:
 * 10001st prime - By listing the first six prime 
 * numbers: 2, 3, 5, 7, 11, and 13, we can see that 
 * the 6th prime is 13. What is the 10 001st prime number?
 * 
 * @author cc dorland
 * 
 */
public class Problem7 {
	
    //cache prime numbers that were identified previously
	private static HashSet<Long> primeNumSet = new HashSet<Long>();
	//cache found prime numbers along with their sequence order 
	private static Map<Integer, Long> primeNumSeqMap = new HashMap<Integer, Long>();
	
	//this method provides the answer submitted to Euler
	public void getAnswerForEuler(){
		getAnswer(10001);
	}
	//this method answers the question and execution time
	public void getAnswer(int num){
		long startTime = System.currentTimeMillis();
		long answer = getPrimeNumberBySeq(num);
		long endTime = System.currentTimeMillis();
		long time = endTime - startTime;
		System.out.println("Answer for Problem 7:  "+answer+"        Execution time in milliseconds: "+time);
	}
	
	//this method check if the number is prime or not
	//it caches if it finds prime numbers
	private boolean isPrimeNumber(long num){
		if (num <= 1) return false;
		if (primeNumSet.contains(num))
			return true;
		if (num == 2){
			primeNumSet.add((long) 2);
			return true;
		}
		if (Utils.isPrime(num)){
			primeNumSet.add(num);
			return true;
		}
		else{
			return false;
		}
	}
	
	//this method finds the sequence order for the prime number
	//it also caches the findings for future fast use
	public long getPrimeNumberBySeq(int seq){
		if (seq <= 0) {
			System.err.println("invalid input number for Problem 7: "+seq);
			return -1;
		}
		
		if (primeNumSeqMap.get(seq) != null)
			return primeNumSeqMap.get(seq);

		int count = 0;
		for (long i=2;i<=Math.sqrt(Long.MAX_VALUE)&&count<seq;i++){
			if (isPrimeNumber(i)){
				primeNumSeqMap.put(++count,i);
			}
		}
		return primeNumSeqMap.get(seq);
	}
	
	//for testing use
	private long testGetPrimeNumberBySeq(int seq){
		long res = getPrimeNumberBySeq(seq);
		if (res != -1)
			System.out.println("input number for Problem 7: "+seq);
		return res;
	}
	//test cases
	public static void main(String[] args) {
		Problem7 prob = new Problem7();
		System.out.println(prob.testGetPrimeNumberBySeq(-1));
		System.out.println(prob.testGetPrimeNumberBySeq(0));
		System.out.println(prob.testGetPrimeNumberBySeq(1));
		System.out.println(prob.testGetPrimeNumberBySeq(2));
		System.out.println(prob.testGetPrimeNumberBySeq(7));
		System.out.println(prob.testGetPrimeNumberBySeq(100));
		System.out.println(prob.testGetPrimeNumberBySeq(6));
		System.out.println(prob.testGetPrimeNumberBySeq(10001));
	}



}
