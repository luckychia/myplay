package projecteuler;

/**
 * This class provides common utils methods used for solving
 * Project Euler Problems
 * 
 * @author cc dorland
 * 
 */
public class Utils {
	
	/**
	 * prime number is positive integer number, greater than 1 and 
	 * can only be divided by 1 and itself;
	 *
	 * @param num
	 * @return true if number is prime number
	 */
	public static boolean isPrime(long num){
		if (num <= 1) return false;
		if (num == 2) return true;
		if ((num % 2) == 0) return false;
		
		//only need to check if the number is a multiple of 
		//any integer between 2 and sqrt root of the number itself
		for (int i=2;i<=Math.sqrt(num);i++){
			if (num%i == 0){
				return false;
			}
		}
		return true;
	}
	
	

}
