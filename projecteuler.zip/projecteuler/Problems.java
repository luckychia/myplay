package projecteuler;

import java.util.HashMap;
import java.util.Map;

/**
 * This class provides singleton instance 
 * used to get the answers to the selected questions
 * and also to test each problem
 * 
 * @author cc dorland
 *
 */
public class Problems {
	private static Problems instance = null;
	private Problem7 problem7 = null;
	private Problem10 problem10 = null;
	private Problem20 problem20 = null;
	private Map<Integer, String> idToProblem = null;
	
	//singleton
	public static Problems getInstance(){
		if (instance == null){
			instance = new Problems();
		}
		return instance;
	}
	
	private Problems(){
		init();
	}
	
    //init with problem description
	private void init(){
		idToProblem = new HashMap<Integer, String>();
		idToProblem.put(7,"Problem 7: 10001st prime - What is the 10 001st prime number?");
		idToProblem.put(10,"Problem 10: Summation of primes - Find the sum of all the primes below two million");
		idToProblem.put(20,"Problem 20: Factorial digit sum - Find the sum of the digits in the number 100!");
		problem7 = new Problem7();
		problem10 = new Problem10();
		problem20 = new Problem20();
	}
	
	public void getAnswerProblem7(){
		problem7.getAnswerForEuler();
	}
	public void getAnswerProblem10(){
	    problem10.getAnswerForEuler();
	}
	public void getAnswerProblem20(){
	    problem20.getAnswerForEuler();
	}
	//run this method to get answers to selected questions 7, 10 and 20
	public void getAnswersForProblems(){
		System.out.println();
		System.out.println(idToProblem.get(7));
		getAnswerProblem7();
		System.out.println();
		System.out.println(idToProblem.get(10));
		getAnswerProblem10();
		System.out.println();
		System.out.println(idToProblem.get(20));
		getAnswerProblem20();
		System.out.println();
	}
	
	//to test each problem - 7, 10 or 20
	public void testProblems(int id, int num){
		if ((id <=0) || (num <=0)){
			System.err.println("Invalid problem id or input number");
		}
		switch(id){
		case 7:
			System.out.println("test problem 7 with input: "+num);
			problem7.getAnswer(num);
			break;
		case 10:
			System.out.println("test problem 10 with input: "+num);
			problem10.getAnswer(num);
			break;
		case 20:
			System.out.println("test problem 20 with input: "+num);
			problem20.getAnswer(num);
			break;
		default:
			System.err.println("Invalid argments");
		}
	}
	
	//if no parameters, it'll run to get all answers asked by ProjectEuler
	//else if there are 2 parameters, they should be problem_id and input_number
	//else invalid paramenters
	public static void main(String[] args) {
		Problems euler = Problems.getInstance();
		if (args.length == 0)
			//answers to selected problems
			euler.getAnswersForProblems();
		else if (args.length == 2){
			int problemId = Integer.parseInt(args[0]);
			int number = Integer.parseInt(args[1]);
			//to get an answer to specified problem with the id and the number
			euler.testProblems(problemId, number);
		}else{
			System.err.println("Invalid argments");
			System.out.println("Argments can be empty or problem id with input number");
			System.out.println("Usage: java [-cp .:./projecteuler/] projecteuler.Problems [problem_id input_number]");
		}
	}

}
